# Three roles I researched

Fictional learner research, with actual source checks on **November 3, 2026**. No application or hiring outcome claimed.

## 1. Palantir: Commercial FDE internship

[Original employer description](https://jobs.lever.co/palantir/4d29249a-d7e8-4c39-880d-3b35d7b2f6f6). Full page read. NYC onsite. Deadline not stated in the reviewed text. Eligibility includes graduation December 2027 or spring 2028 and programming proficiency; travel expectations are 25–50% depending on team/location. This fictional 19-year-old's graduation date is not established, so eligibility is **not confirmed**.

Responsibilities: learn the customer's problem, make architecture/design choices with engineers, build a useful customer-specific application. Skills: programming, working through ambiguity, customer communication.

My evidence: a small game with independently expected tests and a simulated repair workflow. Gap: real client delivery and production-scale data/cloud work. I can prepare for this direction without claiming the course makes me qualified.

## 2. MakiPeople: AI Implementation internship

[Original employer posting](https://jobs.ashbyhq.com/maki/e315491d-2c1d-4656-a5a2-07ce158d5d40). Direct page needs JavaScript; employer text was read in search index. **Availability unconfirmed.** NYC hybrid; six months full time from January 2027. US work authorization without sponsorship is listed. Deadline not stated. Class schedule and work authorization are unconfirmed for the fictional learner.

Responsibilities: configure agents for customer hiring workflows, run structured test/iteration loops, support onboarding across teams. Skills: test-result analysis, careful configuration, organization/communication.

My evidence: explain a user journey, reproduce it, record a failed check and repair. Gap: testing probabilistic AI output and learning actual recruiting processes. A rules-based game is not an AI agent implementation.

## 3. Northwell Health: Senior Product Services & Management Analyst, AI Product team

[Original employer URL, requisition 189916](https://jobs.northwell.edu/job-3/23437682/senior-product-services-management-analyst-melville-ny/). The live URL returned **404** in this trial; indexed employer text remained readable. This is a historical responsibility example; **current availability unconfirmed**, not evidence the job is closed or accepting applicants. Melville, NY. Deadline not confirmed.

Responsibilities: turn business needs into requirements/stories, keep design/test/delivery traceable, support staff documentation/training. Skills: clear requirements, cross-team work, AI-product awareness. It asks for a bachelor's or equivalent and **3–5 years** relevant experience. This is a **future direction, not an immediate internship**.

My evidence: four checkable repair stories connected to actual status/data tests. Gap: healthcare domain knowledge, regulated systems and sustained adoption work. The title is familiar; the AI-team responsibilities are what changed. This research does not prove when a title was invented.

## My two directions and next step

A: engineering implementation / eventual FDE. B: AI product analysis and adoption. I choose A for my portfolio because I enjoy debugging something a person can use. B reminds me to explain the user's need, not just code.

Next: ask a real classmate to follow the account/game journey without coaching, resolve one useful issue, and take the case study to NJIT Career Development Services. I will check eligibility before applying and look for adjacent software/implementation internships as well.
