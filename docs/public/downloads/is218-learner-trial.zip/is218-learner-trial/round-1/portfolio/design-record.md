# One short portfolio record

**Fictional learner:** Leah Rivera, age 19, NJIT IS218 learner simulation. Python calculator/testing experience; little confidence with accounts. Wants creative freedom and an internship direction. Personal qualifications, graduation date and eligibility remain unconfirmed.

**Reader options:** internship reviewer looking for proof of contribution; potential small-project client looking for a useful workflow. Primary reader: internship reviewer. Promise: find my current skills, actual work/assistance, source/checks and résumé quickly. Reader behavior is a hypothesis, not recruiter research.

**Career research:** role-cards.md. Three original employer descriptions; two career directions compared. Immediate fit is unconfirmed; senior healthcare role is a future target.

**Brand:** curious, clear, accountable. Creator/Sage presentation: original game theme plus explainable evidence. A uses a deliberate grid and restrained colors; B uses a playful display treatment. Same content/actions. Chosen A makes checks/contribution easier to scan in this author's inspection; no human preference is claimed.

**Visual references:** the course's actual Bot Lab uses restrained green/cream cards and a loud lime accent; I adapted that evidence hierarchy. B adapts its poster-like type and playful emphasis. These references do not establish that a whole design movement has one appearance.

**Honest persuasion:** let the reader try a local application and inspect test receipts. Offer a short, useful explanation before asking for a conversation. No testimonials, employment, impact metrics or artificial urgency.

**Three stories:** reviewer finds my individual contribution; reviewer distinguishes simulated group work/agent help; reviewer finds résumé, code and profile readiness. Checks: actual local links exist; case studies name assistance/limits; missing owned professional profiles are visibly Pending rather than fake links.

**Review:** real peer task still Pending. An AI-authored trial cannot satisfy human feedback. No hiring effect or usability success inferred from automated checks.
