# IS218 learner trial · Round 1

**November 3, 2026 (Eastern).** Fictional 19-year-old Leah Rivera: knows calculator tests, wants creative freedom/an internship direction, is less confident about accounts. Persona/reactions and customer dialogue are authored teaching simulations. Commands, files, local commits and test results below were actually executed. No real student, teammate, peer, client, public professional profile or remote CI claimed.

## The three products

- **Creative game:** creative-game/. Actual extracted reference, installed using its setup script, customized as Orbit Arcade / Metro Loop. Local demo: http://127.0.0.1:4218. Register a fresh throwaway account; no seeded user.
- **Customer project:** group-customer/. Bench & Bolt option A, trusted local staff only. Actual persistent intake, queue/detail, allowed status decisions and honest next step. Local demo: http://127.0.0.1:4219. No publicly hosted security claim.
- **Portfolio:** portfolio/a.html and b.html share content. A chosen provisionally for evidence scanning. Local preview: http://127.0.0.1:4220/portfolio/a.html. Résumé outline, three role cards and design record included. Real GitHub/LinkedIn/contact details remain Pending rather than invented.

## Actual execution

1. Read current IS218 creative-game, portfolio, career and customer-kit docs.
2. Extracted the actual bot-lab-source.zip into a fresh temporary directory; followed `sh setup.sh`; 30 original checks passed. Repeated package setup in this trial's extracted creative-game directory; 30 passed.
3. Attributed the foundation, initialized a local Git repository, made source baseline commit `bea787c`, changed the brand/opponent explanation and added a focused test. Actual customized run: **31 passed**. Commit `0f96c5fc1415652c7e6dd95ac58ebda0b73a411e`. No fake GitHub issue/PR/CI links.
4. Read the actual customer AGENTS.md and repair deck; wrote an explicitly authored, one-question-at-a-time simulated discovery. Chose staff intake with four bounded stories. Built real Flask/SQLite workflow with CSRF and real status validation.
5. Queue run initially produced **7 passed, 1 failed**: the direct-forgery helper tried to find a CSRF field on a terminal detail page, where the update form correctly does not exist. Changed the helper to obtain a valid same-session token from intake, then directly submit the forbidden transition. Re-run: **8 passed**. This checked backend rejection beyond hiding a button.
6. Reopened original employer sources: Palantir full description read; Maki direct page JS-only but indexed original readable; Northwell original 189916 URL returned404 while indexed employer text remained. Labeled current availability unconfirmed and senior role a future target.
7. Wrote two real portfolio layouts, résumé outline and three role cards. `python3 -B verify_portfolio.py` checked local files/anchors; browser, external/backend actions and keyboard tasks are separate.
8. Started three local servers. First selected preview ports4191/4192/4193 were already occupied; used4218/4219/4220 without stopping anyone else's process. Runtime game data/key are in /tmp, not public source. Local Git provenance and explicit agent attribution retained.

## What confused the learner / next revision

| Observation type | Issue | Small improvement |
| --- | --- | --- |
| Actual setup failure seen during reference creation | Running tests from the course repo root could not import the app. | Give one exact working directory + command. Current ZIP now has pytest.ini and says open bot-lab first. |
| Authored learner reaction | Accounts looked like another whole project until the complete starter made the journey visible. | Put complete local example before partial game-core examples and say what is supplied vs student work. |
| Actual course/reference distinction | Static Bot Lab has no accounts; full local app does. | Label preview vs complete download at the action link. |
| Actual test failure | Terminal page hides update form, so a UI-only test cannot submit a forbidden action. | One example of a valid-CSRF direct request to prove backend rejection. |
| Actual source check | Northwell historical role URL404; Maki direct page unreadable without JS. | Keep future-target/indexed labels; provide a current employer search route before applying. |
| Authored learner reaction | I need encouragement to compare two small ideas rather than build two full applications. | One sentence: two rough directions, one finished account flow. |
| Actual simulation boundary | A generated portfolio cannot legitimately own the fictional student's real LinkedIn/GitHub/contact. | Keep obvious completion placeholders and require the actual student's own links before hand-in. |
| Actual scope boundary | Trusted-local staff intake has no authentication; hosted coordinator app needs it. | Place the local/public choice beside the scenario selection. Never describe the local prototype as a hosted secure app. |

## What remains unfinished

Real peer observation → GitHub issue → meaningful change → retest; genuine equal teammate collaboration; remote student-owned repositories/profiles and CI; actual learner explanation; current internship eligibility; any Docker exercise. The locally executed integration checks do not prove those outcomes. Root's separate CUA walkthrough may add actual browser receipts; no human feedback is inferred from it.

Round 2 should follow the revised starting path, update the same products, re-run checks after changes and record remaining confusions. Do not add another essay/project or invent human participation to fill gaps.
