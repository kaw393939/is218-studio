# Fictional learner group: Bench & Bolt

A real local Flask + SQLite staff-intake prototype, authored with coding-agent assistance. Scenario/characters/agreements are simulated. No actual team participation, peer feedback or real client is claimed.

Run with the environment installed for the creative game:

```sh
../creative-game/.venv/bin/python -B app.py
```

Open http://127.0.0.1:4219. Bind remains **127.0.0.1**: this is the trusted-local-coordinator option, not a publicly hosted application. Public hosting would need server-enforced coordinator authentication and permission checks first.

Checks: `../creative-game/.venv/bin/python -B -m pytest -q -p no:cacheprovider test_queue.py`.

Four agreed scenario stories are implemented in this bounded prototype: valid intake, saved queue/detail, permitted decisions, consistent status/next action. SQLite persists actual records. The integration test reconstructs the app using the same database and confirms saved values/status. No booking, messages or contact details.

**Still pending:** real two-person work division/review, actual GitHub issues/remote CI and real peer observation. The later follow-up-flag change is intentionally not introduced in this first cycle. See customer-kit/CUSTOMER-NOTES.md and SIMULATED-DISCOVERY.md.
