import re
import pytest
from app import create_app

@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING":True,"SECRET_KEY":"test-only-key","DATABASE":str(tmp_path/'repair.sqlite')})

def token(client,path='/'):
    return re.search(rb'name="csrf_token" value="([^"]+)"',client.get(path).data).group(1).decode()

def intake(client,**changes):
    values={"rider":"Rider A","bike":"city","problem":"Brake rub","preferred_day":"Tuesday"}
    values.update(changes)
    return client.post('/',data={**values,"csrf_token":token(client)})

def update(client,id,status):
    return client.post(f'/inquiries/{id}/status',data={"csrf_token":token(client),"status":status})

def test_create_values_queue_and_receipt(app):
    client=app.test_client()
    assert b'No inquiries yet' in client.get('/').data
    assert intake(client).status_code==303
    for path in ('/','/inquiries/1'):
        page=client.get(path).data
        assert b'Rider A' in page and b'Brake rub' in page and b'Pending review' in page
    assert b'Tuesday' in client.get('/inquiries/1').data
    assert b'not confirmed' in client.get('/inquiries/1').data

@pytest.mark.parametrize('values',[{"problem":" "},{"problem":"a"*241},{"bike":"spaceship"},{"preferred_day":"a"*41}])
def test_reject_invalid_intake(app,values):
    client=app.test_client()
    assert intake(client,**values).status_code==400
    assert client.get('/inquiries/1').status_code==404

def test_transitions_and_terminal_rejection(app):
    client=app.test_client();intake(client)
    assert update(client,1,'Completed').status_code==400
    assert b'Pending review' in client.get('/inquiries/1').data
    assert update(client,1,'Accepted').status_code==303
    assert update(client,1,'Completed').status_code==303
    assert update(client,1,'Accepted').status_code==400
    assert b'Completed' in client.get('/').data
    intake(client,rider='Rider B')
    assert update(client,2,'Declined').status_code==303
    assert update(client,2,'Accepted').status_code==400

def test_restart_preserves_same_inquiry(app):
    client=app.test_client();intake(client);update(client,1,'Accepted')
    restarted=create_app({"TESTING":True,"SECRET_KEY":"test-only-key","DATABASE":app.config['DATABASE']})
    assert b'Accepted' in restarted.test_client().get('/inquiries/1').data
    assert b'Brake rub' in restarted.test_client().get('/').data

def test_csrf_required(app):
    client=app.test_client()
    assert client.post('/',data={}).status_code==400
    intake(client)
    assert client.post('/inquiries/1/status',data={'status':'Accepted'}).status_code==400
