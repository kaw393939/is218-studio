"""Fictional local staff-intake prototype. Never bind this unauthenticated app publicly."""
import os
import secrets
import sqlite3
from pathlib import Path
from flask import Flask, abort, flash, g, redirect, render_template, request, url_for
from flask_wtf.csrf import CSRFProtect

STATUSES = {"Pending review": ("Accepted", "Declined"), "Accepted": ("Completed",), "Completed": (), "Declined": ()}


def create_app(config=None):
    app = Flask(__name__)
    state = Path(os.environ.get("REPAIR_STATE", str(Path(__file__).parent / "instance")))
    state.mkdir(parents=True, exist_ok=True)
    app.config.update(SECRET_KEY=secrets.token_hex(32), DATABASE=str(state / "repair.sqlite"), SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    if config:
        app.config.update(config)
    CSRFProtect(app)
    with sqlite3.connect(app.config["DATABASE"]) as connection:
        connection.execute("CREATE TABLE IF NOT EXISTS inquiries (id INTEGER PRIMARY KEY, rider TEXT NOT NULL, bike TEXT NOT NULL, problem TEXT NOT NULL, preferred_day TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending review')")

    def db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
        return g.db

    @app.teardown_appcontext
    def close(_error):
        if "db" in g:
            g.db.close()

    def inquiry(inquiry_id):
        row = db().execute("SELECT * FROM inquiries WHERE id=?", (inquiry_id,)).fetchone()
        if not row:
            abort(404)
        return row

    @app.route("/", methods=["GET", "POST"])
    def queue():
        if request.method == "POST":
            fields = {name: request.form.get(name, "").strip() for name in ("rider", "bike", "problem", "preferred_day")}
            if not 1 <= len(fields["rider"]) <= 40 or fields["bike"] not in ("city", "road", "other") or not 1 <= len(fields["problem"]) <= 240 or len(fields["preferred_day"]) > 40:
                flash("Use a synthetic rider label, listed bike type and a problem of 1–240 characters. Preferred day is at most 40 characters.")
                return render_template("queue.html", rows=db().execute("SELECT * FROM inquiries ORDER BY id DESC").fetchall()), 400
            cursor = db().execute("INSERT INTO inquiries(rider,bike,problem,preferred_day) VALUES(?,?,?,?)", tuple(fields.values()))
            db().commit()
            return redirect(url_for("detail", inquiry_id=cursor.lastrowid), 303)
        return render_template("queue.html", rows=db().execute("SELECT * FROM inquiries ORDER BY id DESC").fetchall())

    @app.get("/inquiries/<int:inquiry_id>")
    def detail(inquiry_id):
        row = inquiry(inquiry_id)
        return render_template("detail.html", row=row, allowed=STATUSES[row["status"]])

    @app.post("/inquiries/<int:inquiry_id>/status")
    def status(inquiry_id):
        connection = db()
        connection.execute("BEGIN IMMEDIATE")
        row = inquiry(inquiry_id)
        new = request.form.get("status", "")
        if new not in STATUSES[row["status"]]:
            abort(400, "That transition is not allowed. Stored status did not change.")
        connection.execute("UPDATE inquiries SET status=? WHERE id=?", (new, inquiry_id))
        connection.commit()
        return redirect(url_for("detail", inquiry_id=inquiry_id), 303)

    @app.after_request
    def no_store(response):
        response.headers["Cache-Control"] = "no-store"
        return response
    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=4219)
