# One simulated customer agreement

**Fictional learner packet, November 3, 2026.** Authored choices, not real students/client interview. The deck was read before implementation. Character mode is now exited.

- Customer: Maya Chen, Bench & Bolt; scenarios/repair-shop.md.
- Selected scope: A, trusted local staff intake. B adds rider-facing form/receipt and was deferred to keep one operating role.
- Audience: coordinator handling walk-in inquiries; all data synthetic.
- Protected finishing week: not part of this first-cycle scope; no new change requested.
- Team contributions: coding-agent-assisted trial only. Equal real teammate contributions and cross-review remain Pending.

## Four stories: simulated agreement → actual implementation

1. Intake: coordinator saves valid city/road/other inquiry; gets generated ID, Pending review. Blank/overlong problem, unsupported bike and overlong preferred day create nothing.
2. Review: queue/detail show exact stored values. Restart with the same SQLite file preserves ID/status/data.
3. Decision: Pending review → Accepted/Declined; Accepted → Completed; terminal states reject updates. Invalid direct transition does not mutate the database.
4. Handoff: queue/detail use the same stored row and explain the next step. Preferred day is never a confirmed booking; no payment/messages promised.

Implementation: app.py + templates. Actual checks: test_queue.py. No static preview is called persistence.

Local-only boundary: no login is needed for this trusted prototype; it binds 127.0.0.1. It must not be published as an unprotected coordinator app. A hosted version requires actual server permissions and direct-request tests.

## One change

Not introduced. The follow-up flag remains deferred. No invented second change or customer acceptance.

## Final evidence

Run command and result recorded in ../TRIAL-NOTES.md after execution. Real peer task/issue/change/retest, remote source/CI and individual teammate explanation remain Pending. Simulation is not human validation.
