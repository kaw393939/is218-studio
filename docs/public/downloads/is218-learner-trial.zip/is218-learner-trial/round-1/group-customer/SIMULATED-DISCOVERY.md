# Authored customer-mode trial

This is a clearly authored fictional dialogue for a fictional learner packet. The agent inspected the actual AGENTS.md and scenario deck; it does not claim a real interview, separate model evaluation or human team decision.

**Learner prompt:** Read customer-kit/AGENTS.md. Start customer mode.

**Customer facilitator:** This exercise is fictional. Choose Bench & Bolt repair shop, Harbor Helpers volunteers or Clear Shelf supply desk. Which does your team want?

**Fictional learner:** Bench & Bolt. A repair queue seems small enough to finish while still having useful state changes.

**Maya, simulated:** Repair requests arrive in scraps of paper and messages. I need one queue and an honest status. What do you need to clarify?

**Fictional learner:** Who enters the request? Could we start with staff rather than a separate rider form?

**Maya, simulated:** Option A is staff intake; option B adds rider intake and a receipt. Both use the same queue. Which scope do you propose?

**Fictional learner:** A: a trusted local coordinator enters synthetic walk-ins. Keep city/road/other, short problem, optional preferred day. A preference is not a booking.

**Maya, simulated:** That matches option A. What should a completed request allow next?

**Fictional learner:** Nothing: Completed and Declined are terminal. Pending review may become Accepted or Declined; only Accepted can become Completed. Our four stories are in CUSTOMER-NOTES.md. We choose local-only; public deployment and sign-in are deferred.

**Simulated scope summary:** Those four stories match the deck. This is a simulated planning agreement, not customer acceptance of working code. Checks remain unverified until run.

**Learner:** Exit customer mode.

Implementation/testing happened as the ordinary coding assistant afterward. No bounded follow-up change was requested during this first cycle. Real peer review remains pending.
