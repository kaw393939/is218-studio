# IS218 Round 1: a realistic, attributed learner packet

Start with TRIAL-NOTES.md. Three real local artifacts are present; source, simulated choices and actual verification are distinguished.

- Orbit Arcade: creative-game/ · 31 local tests passed · actual local Git history.
- Bench & Bolt: group-customer/ · four persistent workflow stories · 8 request/database checks passed.
- Portfolio: portfolio/a.html and b.html · résumé outline, three role cards and design record. Own profile/contact and real peer evidence remain Pending.

No real person/client endorsement, remote CI or genuine team participation is claimed. Source environments may be reused locally; do not publish throwaway runtime databases or keys.

## Run the three products

Open three terminals from this packet's round-1 directory:

1. `cd creative-game` then `sh run.sh` → http://127.0.0.1:4218. First use: `sh setup.sh`.
2. `cd group-customer` then `../creative-game/.venv/bin/python -B app.py` → http://127.0.0.1:4219.
3. `python3 -B -m http.server 4220 --bind 127.0.0.1` → http://127.0.0.1:4220/portfolio/a.html.

Use made-up accounts/data. Stop each local process with Ctrl+C. If a port is occupied, choose a free port and update the matching local portfolio demo link; do not stop another person's server.

The second-round review reuses these same projects rather than creating three new ones. See ../round-2/TRIAL-NOTES.md.
