# Reference and trial attribution

This is a fictional 19-year-old NJIT learner walkthrough, authored and executed with coding-agent assistance on November 3, 2026. It is not a real student or internship claim.

Foundation: the complete IS218 Bot Lab reference app downloaded from the course repository. Framework auth, SQLite, templates and original 30 tests are supplied reference code, not independently invented by the trial learner. Trial work changes the game brand/opponent explanation and adds one focused actual integration check. Local commits are real; no GitHub issue, real peer or remote CI is claimed.
