# Fictional learner: Leah Rivera

**Career direction:** software implementation / eventual FDE. I can explain calculator tests; accounts still feel unfamiliar.

**Creative choice:** Orbit Arcade, a transit-inspired prediction game. I considered a branching space story but chose the rhythm game so I can finish the whole account flow. My Metro Loop opponent makes the three-move cycle explicit.

**Own trial contribution:** changed the supplied brand/opponent explanation and added one integration check for the label, next-action hint and expected saved win. The authentication/database/game foundation remains attributed starter assistance. No real peer has reviewed it.

**Promise:** sign in, predict a move, save the result, return to my dashboard and maintain my account. The supplied checks establish the technical foundation; I still need a real reader to explain the game without coaching.
