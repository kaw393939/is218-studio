"""File/anchor checks only. No browser, external availability or accessibility claim."""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse, unquote

root=Path(__file__).resolve().parent
class Links(HTMLParser):
    def __init__(self):
        super().__init__();self.urls=[];self.ids=set()
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.add(attrs['id'])
        for key in ('href','src'):
            if key in attrs:self.urls.append(attrs[key])

count=0
for page in (root/'portfolio').glob('*.html'):
    doc=Links();doc.feed(page.read_text())
    for raw in doc.urls:
        parsed=urlparse(raw)
        if parsed.scheme:continue
        destination=page.parent/unquote(parsed.path) if parsed.path else page
        assert destination.is_file(), f'{page.name}: {raw}'
        if parsed.fragment:
            target=Links();target.feed(destination.read_text())
            assert parsed.fragment in target.ids,raw
        count+=1
print(f'{count} local portfolio link/asset/anchor references resolve; external/backend/keyboard tasks are separate.')
