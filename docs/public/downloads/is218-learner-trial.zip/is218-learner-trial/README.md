# IS218: two rounds of a fictional learner trial

Start with round-1/README.md for the three products and exact run commands. Read round-1/TRIAL-NOTES.md and round-2/TRIAL-NOTES.md for executed checks, observed failures, fixes and remaining human work. Round 2 updates the SAME products in round-1.

This is an attributed coding-agent-assisted teaching packet, not a real student's grades/client endorsement. No virtual environment, database, signing key, actual user/session, .git directory or fake professional profile is included. creative-game/ACTUAL-LOCAL-COMMITS.txt preserves the real local commit record; the working repository remains in the instructor's local trial output.

Python3.12+ intended; actual local receipts used3.14.7. Install with round-1/creative-game/setup.sh, then follow the three-terminal setup. Portfolio demo URLs point only to the matching local servers. The repair app is a trusted local staff prototype and must not be publicly exposed without authentication. Human peer review and real student-owned profiles remain pending.
