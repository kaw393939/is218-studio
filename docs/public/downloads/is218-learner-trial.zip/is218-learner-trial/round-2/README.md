# Second round

Use the same three products in ../round-1. TRIAL-NOTES.md records actual replay, a corrected startup/demo inconsistency, checks and remaining human evidence. `final-download/bot-lab` is the freshly extracted source used for the second setup run; it is the uncustomized supported reference.
