# IS218 learner trial · Round 2

**November 3, 2026.** Same fictional learner and the same three projects as Round 1. Authored reactions remain simulation; the checks/commits below are actual execution. No real peer or team participation is claimed.

## Revised starting path

Read the revised overview, full-game guide, individual brief, customer simulator and AI-role page. The overview now begins with three products and a next action. The individual brief explicitly says two rough directions, one finished backend. The customer page separates trusted-local staff from protected public coordinator access. The Northwell example now identifies the historical404 and offers the employer search route. These changes address the first-round scope/link confusions without adding a new project.

## Actual work and retest

- Extracted the final clean source ZIP again into `final-download/bot-lab`, followed `sh setup.sh`, ran the documented checks: **30 passed** on Python3.14.7. Classroom Python3.12 remains an environment to establish through actual CI, not assumed from this run.
- Reused Orbit Arcade rather than making another game. Caught a real mismatch: the customized run script/README defaulted to4190 while the portfolio demo linked4218. Changed the custom default and instructions to4218. Actual local commit: `17f0ed51da32fb828ff827df446982a471190764`. Re-ran the customized integration suite: **31 passed**.
- Re-ran the persistent repair workflow checks: **8 passed**. Valid inquiry, stored values/status, forbidden transitions, terminal state, same-store restart and CSRF remain checked. No follow-up flag was introduced.
- Added one short three-terminal setup to Round1 README and an explicit local-server notice to both portfolio layouts. File/anchor check: **50 references resolve**. This is not a browser or external-link availability claim.
- An optional maintainer archive check was confusing in the first extracted packet because an archive cannot contain its own ZIP. Removed the unnecessary maintainer `package.py` from the student ZIP; it remains in course source for CI. Final student ZIP: **22 clean source files**, re-extracted/setup/tested successfully. No runtime key/database/environment/cache is shipped.

## The end products now

1. **Orbit Arcade:** complete local account/game/history/maintenance application based on attributed reference code, with a custom brand/opponent explanation and one added focused check. Run `round-1/creative-game`; demo4218.
2. **Bench & Bolt:** real local trusted-staff repair intake/queue/status/detail workflow, four bounded stories, SQLite persistence and8 integration checks. Run `round-1/group-customer`; demo4219. Public authentication remains outside this explicitly local option.
3. **Portfolio:** two lightweight layouts with the same case studies, accurate attribution, three role cards and résumé outline. Chosen A; local static preview4220. Real student's owned profiles/contact and real peer evidence remain unfilled by design.

The coordinating agent separately used CUA on the **supplied reference**, not this fictional learner's customized game: registration/empty dashboard, paper beating Clockwork's rock, one saved win and saved display-name edit. That actual receipt is in the reference TEST-NOTES. It cannot be counted as a real peer review.

## Remaining learner needs

The work now has a clearer starting point and working examples. The main remaining step is human participation: one real person should try each project; teammates must actually divide and review work; a real student must supply owned profiles and explain decisions. Those cannot be completed by role-play. A fresh classroom Python3.12 setup/CI result, current job eligibility and the later Docker lesson are also separate evidence.

**Authored learner reaction:** the complete account/game foundation makes creativity feel possible. The most helpful instruction is still “choose one small experience and keep improving it.” Keep the review submission to links plus changed/checked/next rather than another report.
